<?php
include '../config/db_connect.php';
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <?php include "title_icon.php"; ?>

    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link href="../css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="../css/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="../css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

    <!-- fullCalendar -->
    <link href="../css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="../css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="../css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <!-- DATA TABLES -->
    <link href="../css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../css/style.css" rel="stylesheet" type="text/css" />
    <link href="../css/AdminLTE.css" rel="stylesheet" type="text/css" />

</head>

<body class="skin-black">
    <?php include('header.php') ?>

    <div class="wrapper row-offcanvas row-offcanvas-left">
        <!-- Include left Menu -->
        <?php include "left_menu.php" ?>
        <aside class="right-side">
            <section class="content-header">
                <h1 class="text-primary">Employee Loan Payment<h1>
                        <button type="button" class="btn btn-primary btn-lg">
                            <i class="fa fa-plus-square-o" aria-hidden="true"></i>
                            Add New
                        </button>
            </section>
            <section class="content">
                <div class="row">
                    <div class="col-xs-12 connectedSortable">
                        <div class="box border">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Job_Id</th>
                                        <th>Employee Info</th>
                                        <th>Company Info</th>
                                        <th>Total Loan</th>
                                        <th>Amount To Pay</th>
                                        <th>Total Paid Loan</th>
                                        <th>Laon Balance</th>
                                        <th>Payment Date</th>
                                        <th>Status</th>
                                        <th>Note</th>
                                        <th style="width: 100px;"><i class="fa fa-cog"></i></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM employee_loan_payment A 
                                            LEFT JOIN employee_registration B on B.er_id=A.elp_job_id
                                            LEFT JOIN gender C on C.ge_id=B.er_gender_id
                                            LEFT JOIN position D on D.position_id=B.er_position_id
                                            LEFT JOIN company E on E.c_id=A.elp_company_id
                                            LEFT JOIN user_branch F on F.ub_id=A.elp_branch_id
                                            LEFT JOIN department G on G.de_id=A.elp_department_id
                                            LEFT JOIN user H on H.id=A.elp_user_id
                                            LEFT JOIN text_employee_loan_payment_status I on I.lps_id=A.elp_status_id
                                            ";
                                    $result = $connect->query($sql);
                                    // $row=$result->fetch_assoc();
                                    // echo $row['ef_date'];
                                    $i = 1;
                                    while ($row = $result->fetch_assoc()) {
                                        $v_i = $i++;
                                        $v_job_id = $row["er_job_id"];
                                        $v_name_kh = $row["er_name_kh"];
                                        $v_gender_id = $row["ge_name"];
                                        $v_position_id = $row["position"];
                                        $v_company_id = $row["c_name_kh"];
                                        $v_branch_id = $row["ub_name"];
                                        $v_department_id = $row["de_name"];
                                        $v_user_id = $row["username"];
                                        $v_total_loan = $row["elp_total_loan"];
                                        $v_amount_to_pay = $row["elp_amount_to_pay"];
                                        $v_total_paid_loan = $row["elp_total_paid_loan"];
                                        $v_loan_balance = $row["elp_loan_balance"];
                                        $v_payment_date = $row["elp_payment_date"];
                                        $v_status_id = $row["lps_name"];
                                        $v_note = $row["elp_note"];
                                    ?>
                                        <tr>
                                            <td><?php echo $v_i; ?></td>
                                            <td><?php echo $v_job_id; ?></td>
                                            <td>
                                                <i>Name: </i><?php echo $v_name_kh; ?><br>
                                                <i>Sex: </i><?php echo $v_gender_id; ?><br>
                                                <i>Position: </i><?php echo $v_position_id; ?>
                                            </td>
                                            <td>
                                                <i>Company Name: </i><?php echo $v_company_id; ?> <br>
                                                <i>Branch: </i><?php echo $v_branch_id; ?> <br>
                                                <i>Department: </i><?php echo $v_department_id; ?> <br>
                                                <i>User: </i><?php echo $v_user_id; ?>
                                            </td>
                                            <td><?php echo $v_total_loan; ?>$</td>
                                            <td><?php echo $v_amount_to_pay; ?>$</td>
                                            <td><?php echo $v_total_paid_loan; ?>$</td>
                                            <td><?php echo $v_loan_balance; ?>$</td>
                                            <td><?php echo $v_payment_date; ?></td>
                                            <td><?php echo $v_status_id; ?></td>
                                            <td><?php echo $v_note; ?></td>
                                            <td>
                                                <!--insert-->
                                                <a data-toggle="modal" data-target="#myModal_update" class="btn btn-primary btn-sm">
                                                    <i style="color: white;" class="fa fa-edit"></i>
                                                </a>
                                                <!-- delete -->
                                                <a onclick="return confirm('Are you sure to delete ?');" 
                                                    href="employee_loan_payment.php?del_id=<?php echo $row['elp_id']; ?>" class="btn btn-danger btn-sm">
                                                    <i style="color:white;" class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>

                            </table>

                        </div>

                    </div>


                </div>

            </section>


        </aside>
        <div>

            <!-- jQuery 2.0.2 -->
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
            <!-- jQuery UI 1.10.3 -->
            <script src="../js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
            <!-- Bootstrap -->
            <script src="../js/bootstrap.min.js" type="text/javascript"></script>
            <!-- Morris.js charts -->
            <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
            <script src="../js/plugins/morris/morris.min.js" type="text/javascript"></script>
            <!-- Sparkline -->
            <script src="../js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
            <!-- jvectormap -->
            <script src="../js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
            <script src="../js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
            <!-- fullCalendar -->
            <script src="../js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
            <!-- jQuery Knob Chart -->
            <script src="../js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
            <!-- daterangepicker -->
            <script src="../js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
            <!-- Bootstrap WYSIHTML5 -->
            <script src="../js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
            <!-- iCheck -->
            <script src="../js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

            <!-- AdminLTE App -->
            <script src="../js/AdminLTE/app.js" type="text/javascript"></script>

            <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
            <script src="../js/AdminLTE/dashboard.js" type="text/javascript"></script>

            <!-- page script -->
            <script type="text/javascript">
                $(function() {
                    $("#example1").dataTable();
                    $('#example2').dataTable({
                        "bPaginate": true,
                        "bLengthChange": false,
                        "bFilter": false,
                        "bSort": true,
                        "bInfo": true,
                        "bAutoWidth": false
                    });
                });
                $(function() {
                    $("#menu_task_manager").addClass("active");
                    $("#company_task").addClass("active");
                    $("#company_task").css("background-color", "##367fa9");

                    $('#info_data').dataTable();
                });
            </script>

</body>

</html>