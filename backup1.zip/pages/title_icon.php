 <link rel="icon" href="../img/login_logo.png" type="image/x-icon">
    <title>HR System</title>