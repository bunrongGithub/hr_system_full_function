<?php 

$servername = "localhost";
$username = "newsoft15_hr_wewin_u";
$password = "Hh@123456789Hh@123456789";
$dbname = "newsoft15_hr_wewin_db";
	
// creating the connection
$connect = new mysqli($servername, $username, $password, $dbname);

// checking the connection
if(!$connect->connect_error) {
	date_default_timezone_set("Asia/Bangkok");
	ob_start();
	session_start();
}
else {
	die("Connection Failed : " . $connect->connect_error);
}

?>